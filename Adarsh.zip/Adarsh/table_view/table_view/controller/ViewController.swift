//
//  ViewController.swift
//  table_view
//
//  Created by TRAINING on 29/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var tableVIew: UITableView!
    
    var array = ["CSE","ECE","MECH","EEE","CILVIL","CSE","ECE","MECH","EEE","CILVIL","CSE","ECE","MECH","EEE","CILVIL","CSE","ECE","MECH","EEE","CILVIL","CSE","ECE","MECH","EEE","CILVIL","CSE","ECE","MECH","EEE","CILVIL","CSE","ECE","MECH","EEE","CILVIL","CSE","ECE","MECH","EEE","CILVIL"]
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return array.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let departmnet = array[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        //cell.lblName.text = departmnet
        cell.lblName1.text = departmnet
        
        return cell
    }
    
    
    
    
    
    
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

