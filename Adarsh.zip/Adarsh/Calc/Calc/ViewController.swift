//
//  ViewController.swift
//  Calc
//
//  Created by TRAINING on 14/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var num1 : Int = 0
    var num2 = 0
    var result = 0
    
    @IBOutlet weak var txtNum1: UITextField!
    @IBOutlet weak var txtNum2: UITextField!
    @IBOutlet weak var txtResult: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnAdd(_ sender: UIButton) {
        num1 = Int(txtNum1.text!)!
        num2 = Int(txtNum2.text!)!
        result = num1 + num2
        txtResult.text = String(result)
        
    }
    

    @IBAction func btnMul(_ sender: UIButton) {
        num1 = Int(txtNum1.text!)!
        num2 = Int(txtNum2.text!)!
        result = num1 * num2
        txtResult.text = String(result)
    }
    
    @IBAction func btnDiv(_ sender: UIButton) {
        num1 = Int(txtNum1.text!)!
        num2 = Int(txtNum2.text!)!
        result = num1 / num2
        txtResult.text = String(result)
    }
    
    @IBAction func btnSub(_ sender: UIButton) {
        num1 = Int(txtNum1.text!)!
        num2 = Int(txtNum2.text!)!
        result = num1 - num2
        txtResult.text = String(result)
    }
}

