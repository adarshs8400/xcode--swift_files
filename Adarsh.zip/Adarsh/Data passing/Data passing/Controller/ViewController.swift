//
//  ViewController.swift
//  Data passing
//
//  Created by TRAINING on 28/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblData1: UILabel!
    @IBOutlet weak var txtData: UITextField!
    
    var receive = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblData1.text = receive
       
       
    }

    
    @IBAction func btnSubmit(_ sender: UIButton) {
        
        performSegue(withIdentifier: "next", sender: .none)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let newObj = segue.destination as!
        ViewController2
        newObj.receiveData = txtData.text!
    }
   
}

