//
//  ViewController2.swift
//  Data passing
//
//  Created by TRAINING on 28/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
 
    var receiveData = ""
    
    
    @IBOutlet weak var txtData1: UITextField!
    
    
    
    @IBOutlet weak var lblData: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblData.text = receiveData
        
    }
   
    
    
    @IBAction func btnSubmit2(_ sender: Any) {
        
        performSegue(withIdentifier: "cell", sender: .none)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let newObj1 = segue.destination as!
        ViewController
        
        newObj1.receive = txtData1.text!
    }
   
}
