//
//  TableViewController.swift
//  Tableview
//
//  Created by TRAINING on 27/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    var dep = ["CSE","EEE","ECE","MECH","CSE","EEE","ECE","MECH","CIVIL","CSE","EEE","ECE","MECH","CIVIL","CSE","EEE","ECE","MECH","CIVIL","CSE","EEE","ECE","MECH","CIVIL","CSE","EEE","ECE","MECH","CIVIL","CSE","EEE","ECE","MECH","CIVIL","CSE","EEE","ECE","MECH","CIVIL","CSE","EEE","ECE","MECH","CIVIL"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dep.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let department = dep[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = department
        cell.detailTextLabel?.text = department
       
        return cell
    }
    
}
    

