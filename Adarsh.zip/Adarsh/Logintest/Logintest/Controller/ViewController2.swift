//
//  ViewController2.swift
//  Logintest
//
//  Created by TRAINING on 29/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    var receivedData1 = ""
    var receivedData2 = ""
    
    
    @IBOutlet weak var lblUser: UILabel!
    
    @IBOutlet weak var lblPass: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblUser.text = receivedData1
        lblPass.text = receivedData2
        
    }
    

   

}
