//
//  ViewController.swift
//  Logintest
//
//  Created by TRAINING on 29/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtUser: UITextField!
    
    @IBOutlet weak var txtPass: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnSubmit(_ sender: UIButton) {
        
        performSegue(withIdentifier: "next", sender: .none)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let obj1 = segue.destination as! ViewController2
        
        obj1.receivedData1 = txtUser.text!
        obj1.receivedData2 = txtPass.text!
    }
}

