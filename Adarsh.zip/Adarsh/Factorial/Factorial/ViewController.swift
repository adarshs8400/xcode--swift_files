//
//  ViewController.swift
//  Factorial
//
//  Created by TRAINING on 14/12/21.
//  Copyright © 2021 vjec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtNum: UITextField!
    @IBOutlet weak var lblResult: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnFact(_ sender: UIButton) {
        var fact = 1
        let number = Int(txtNum.text!)!
        for n in 1 ... number{
            fact = fact * n
        }
        lblResult.text = String(fact)
    }
    
}

