//
//  Dice ViewController.swift
//  Segues
//
//  Created by Swift Training on 28/11/21.
//  Copyright © 2021 Swift Training. All rights reserved.
//

import UIKit

class Dice_ViewController: UIViewController {
    
     var Randomnum = 0
    
    var diceImg = ["Dice 1","Dice 2","Dice 3","Dice 4","Dice 5","Dice 6"]

    @IBOutlet weak var diceImage: UIImageView!
    override func viewDidLoad()
    
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func rollBtn(_ sender: UIButton) {
        
        Randomnum = Int(arc4random_uniform(6))
        diceImage.image = UIImage(named : diceImg[Randomnum])
        
    }
    
}
